/****h* galaxy_tools/WOPR.c [1.3] *
*
*  NAME
*    WOPR -- Galaxy Battle Simulator.
*
*  COPYRIGHT
*    (c) Maverick Software Development 1996
*
*  FUNCTION
*    Predicts the outcome of a battle between two fleets.
*    A fleet is given by a set of groups and ship types.
*
*    The program predicts the chance to win or draw a battle.
*    In addition is predicts the min, max, and avg survival rate
*    of each group.
*
*    It assumes the following:
*      o All cargo ships are empty.
*      o Eff shield strenght is never more than 999999.99
*      o There are no more than 32767 groups.
*
*    Use the following command line to start it:
*
*    WOPR <fleetfile1> <fleetfile2> <count> [V] [D]
*
*      <fleetfile> -- files with list of ship types and groups
*
*      It should have the following layout.
*      -----------
*      <ship type ally1>
*      ...
*      <ship type ally1>
*      @
*      <group entry ally1>
*      ...
*      <group entry ally1>
*      @
*      <ship type ally2>
*      ...
*      <ship type ally2>
*      @
*      <group entry ally2>
*      ...
*      <group entry ally2>
*      @
*      ----------
*
*      <ship type> has the same layout as the list of ship types
*      found in a turn report
*         Layout: <name> <drive> <attacks> <weapons> <shield> <cargo>
*      <group entry> has the same layout as the one found in a turn
*      report.
*         Layout: <#-of-ships> <name> <drive-tech> <shield-tech> <cargo-tech>
*         All additional information is ignored.
*
*  Example file:
*
*      Angel      2.5   1   1.5   0.0   0
*      Duivel     40.0   1  30.0  28.0   1
*      Zwerver     1.0   0   0.0   0.0   0
*      Egel       40.0   9   7.0  23.0   1
*      @
*       148  Zwerver   1.6  0  0  0  -  0  vortex
*       1    Egel      2.33 1  2  0  -  0  vortex
*       2    Duivel    3    2  2  0  -  0  vortex
*      @
*
*      <count> -  number of battle that will used to predict the
*         outcome of a battle. The more battles the more
*         accurate the predictions.  Some test I done suggest that
*         the predictions can be as accurate as +/- 1%.
*
*      [V] -  Verbose flag
*         0 = keep information to a minimum
*         1 = print additional information: that is which ship
*             attacks which ship
*
*      [D] - Debug flag
*         0 = Don't Print debug information
*         1 = Do print it.
*
*  AUTHOR
*    Frans Slothouber.
*
*  CREATION DATE
*    July 29 - 1995
*
*  MODIFICATION HISTORY
*    July 31 1995 -- Version 0.99 preliminary version.
*    Aug  03 1995 -- Version 1.0a
*    Aug  13 1995 -- Version 1.2
*    Feb  03 1996 -- Version 1.3
*      Made the fleet file parser less strict -- empty lines in
*      the fleet files are allowed now.
*
*  NOTES
*    Report bugs to: fslothouber@acm.org
*
*    Has beem succesfully compiled with:
*    o SAS/C 6.50 on an Amiga 1200
*      With the options:
*      MATH=STANDARD
*      CPU=68020
*      ANSI
*      LINK
*      STRICT
*      PROGRAMNAME=WOPR
*
*    o gcc  on a Sun Sparc Station, sun OS 4.1
*      using: gcc WOPR.c -o WOPR -lm
*
*******
*/


#include <stdio.h>
#include <ctype.h>
#include <strings.h>
#include <stdlib.h>
#include <math.h>

/* RevCo : VER 3 REV 0 SUB 0 COM 4 STG 1 */

#define	VERSION		3
#define	REVISION		0
#define	COMPILATION	4
#define	STAGE			"[beta]"
#define	NAME			"WOPR"
#define	VERS			"3.0"
#define	COMP			"4"
#define	DATE			"03.02.96"
#define	TIME			"10:29:26"
#define	VSTRING		"WOPR 3.0[beta] (03.02.96)\n\r"
#define	VERSTAG		"\0$VER: WOPR 3.0[beta] (03.02.96)"

#define eq ==

#define TRUE  1
#define FALSE 0
#define NAME_LENGTH 22

/* Number of tries before the battle array will be compacted */
#define MAX_REPEAT 10


struct ship_type
{
  struct ship_type *next ;
  char name[NAME_LENGTH] ;
  float drive, attacks, weapons, shield, cargo ;
} ;


struct group
{
  struct group *next ;
  int number ;
  int temporary ;
  int number_survived ;
  int max_number_survived ;
  int min_number_survived ;
  struct ship_type *type ;
  float drive_tech ;
  float weapons_tech ;
  float shield_tech ;
  float cargo_tech ;
  float cargo_load ;
  float eff_shield ;
  float eff_weapons ;
  float eff_range ;
  float total_mass ;
} ;


struct player
{
  struct group *groups ;
  struct group **group_array ;
  short  *bat_array ;
  struct ship_type *types ;
  int    number_of_ships ;
  int    number_of_armed_ships ;
  int    selected_armed_ship ;
  int    bat_array_size ;
  int    cur_bat_array_size ;
  int    group_array_size ;
} ;

float my_log (float x) ;
float my_log2 (float x) ;
unsigned long     Random            (void) ;
float             Roll_Dice         (void) ;
void              Reset_Random      (unsigned long seed) ;

int               Load_Fleet_Information (struct player *P, char *fleet_file_name) ;
void              Print_Ship_Types       (struct ship_type *cur_ship) ;
void              Print_Groups           (struct group *cur_group) ;

short            *Alloc_Bat_array   (struct group *the_groups, int *size) ;
struct group    **Alloc_Group_array (struct group *the_groups, int *size) ;
int               Init_Bat_array    (short *bat_array, struct group *the_groups) ;
void              Randomize_Armed_Ships (short *bat_array, int number_of_armed_ships) ;
void              Compute_Eff_Shield_And_Weapon (struct group *the_groups) ;

void              Probe             (struct player *P1, struct player *P2) ;
int               Do_Battle         (struct player *P1, struct player *P2) ;
void              Fight             (struct player *P1, struct player *P2, int *al, int *sl) ;
int               Select_a_Ship     (struct player *P) ;
int               Select_Armed_Ship (struct player *P) ;
struct group     *Max_Weapons       (struct player *P) ;
struct group     *Min_Shield        (struct player *P) ;
int               Is_A_Draw         (struct player *P1, struct player *P2) ;
int               Can_Destroy       (struct group *g1, struct group *g2) ;

void              Init_Survival_Count  (struct group *cur_group) ;
void              Count_Survivors      (struct player *P) ;
void              Print_Survival_Count (struct group *cur_group) ;


int verb   = FALSE ;   /* Print additional information during simulation */
int debug  = FALSE ;   /* Print even more information */
int max_battle = 0 ;   /* Number of battles simulated */


char version [] = VERSTAG ;

#define LINE_BUFFER_LENGTH 100
char line_buffer[LINE_BUFFER_LENGTH] ;

main (int argc, char **argv)
{
  struct player P1, P2 ;

  setbuf (stdout, NULL) ; 
  Reset_Random (111167) ;
  printf ("WOPR ver:"VERS"   Comp ("COMP")  ") ;
  printf ("(c) Maverick Software Development\n") ;
  if (argc > 3)
  {
    max_battle = atoi (argv[3]) ;
    if (argc > 4) verb  = atoi (argv[4]) ;
    if (argc > 5) debug = atoi (argv[5]) ;
    if (Load_Fleet_Information (&P1, argv[1]) &&
        Load_Fleet_Information (&P2, argv[2])) Probe (&P1, &P2) ;
  }
  else
  {
    printf ("Usage: WOPR <fleetfile1> <fleetfile2> <count> <V> <D>\n") ;
  }
}


/****** WOPR.c/Probe [1.0a] *
*
*  NAME
*    Probe -- Compute the win-chance of player 1
*  SYNOPSIS
*    result = int Probe (struct player *P1, struct player *P2)
*  FUNCTION
*    Figth max_battle battles and use the results to compute
*    the chance of winning for player 1.
*  INPUTS
*    P1  -- player structure of player 1
*    P2  -- player structure of player 2
*  BUGS
*
*  SEE ALSO
*
**********
*/

void Probe (struct player *P1, struct player *P2)
{
  int battle, w_P1, w_P2 ;

  setbuf (stdout, NULL) ;
  printf ("\n\n====== Battle Simulation =====\n") ;
  printf ("-- Battle Starts...\n") ;

  Init_Survival_Count (P1->groups) ;
  Init_Survival_Count (P2->groups) ;
  for (battle = 0, w_P1 = 0, w_P2 = 0 ;
       battle < max_battle ;
       battle++)
  {
    int res ;

    printf ("% 4d", battle+1) ;
    if ((battle & 15) eq 15) printf ("\n") ;

    if (battle & 1)
    {
      res = Do_Battle (P1, P2) ;
    }
    else
    {
      res = Do_Battle (P2, P1) ;
      if (res eq 1)      res = 2 ;
      else if (res eq 2) res = 1 ;
    }
    switch (res)
    {
      case 0 : if (verb) printf ("Draw.\n") ; break ;
      case 1 : w_P1++ ; if (verb) printf ("Player 1 Wins.\n") ; break ;
      case 2 : w_P2++ ; if (verb) printf ("Player 2 Wins.\n") ; break ;
      default : printf ("Error!\n") ;
    }
    Count_Survivors (P1) ;
    Count_Survivors (P2) ;
  }
  printf ("\n\n-- Ready...\n\n") ;
  printf ("======== Battle Report =======\n\n") ;
  printf ("Battles fought: %d\n", max_battle) ;
  printf ("Player 1 wins %d battles\n", w_P1) ;
  printf ("Player 2 wins %d battles\n", w_P2) ;
  if (w_P1 + w_P2) printf ("Player 1 has a %f %c chance to win.\n",
                            100.0*(float)(w_P1)/(float)(max_battle),37) ;
  else             printf ("Game is a draw.\n") ;

  printf ("\n== Player 1 Survival Count ==\n") ;
  Print_Survival_Count (P1->groups) ;
  printf ("\n== Player 2 Survival Count ==\n") ;
  Print_Survival_Count (P2->groups) ;
}


/****** WOPR.c/Do_Battle [1.0a] *
*
*  NAME
*    Do_Battle -- fight a battle between players.
*  SYNOPSIS
*    result = int Do_Battle (struct player *P1,struct player *P2)
*  FUNCTION
*
*    Algorithm:
*      Repeat until there either players hasn't any ships left or
*             the game is a draw.
*      { 
*        Randomly select a ship, S1, of player 1 that hasn't fired yet
*        For all the attacks of S1
*        {
*          Select a ship S2 of player 2 and fire on it
*        }
*        Randomly select a ship, S2, of player 2 that hasn't fired yet 
*        For all the attacks of S2
*        {
*          Select a ship S1 of player 1 and fire on it
*        }
*      }
*
*    To adjust for the fact that Player 1 always starts firing, the
*    players are swaped randomly in the functions that calls this
*    function.
*  INPUTS
*    P1  -- player structure of player 1
*    P2  -- player structure of player 2
*  RESULT
*    0  -- Battle is a draw.
*    1  -- Player 1 wins.
*    2  -- Player 2 wins.
*  BUGS
*
*  SEE ALSO
*
**********
*/


int Do_Battle (struct player *P1, struct player *P2)
{
  int al1, al2, sl1, sl2, stop_battle, draw ;

  P1->number_of_armed_ships = Init_Bat_array (P1->bat_array, P1->groups) ;
  P2->number_of_armed_ships = Init_Bat_array (P2->bat_array, P2->groups) ;

  if (P1->number_of_armed_ships && P2->number_of_armed_ships)
  {
    Randomize_Armed_Ships (P1->bat_array, P1->number_of_armed_ships) ;
    Randomize_Armed_Ships (P2->bat_array, P2->number_of_armed_ships) ;

    P1->cur_bat_array_size = P1->bat_array_size ;
    P2->cur_bat_array_size = P2->bat_array_size ;

    if (debug) printf ("-- Fighting\n") ;
    for (sl1 = 1, sl2 = 1, al1 = 1, al2 = 1, draw = FALSE ;
         sl1 && sl2 && !draw ; )
    {
      P1->selected_armed_ship = 1 ;
      P2->selected_armed_ship = 1 ;

      for (stop_battle = FALSE;
           !stop_battle;
          )
      {
        Fight (P1, P2, &al1, &sl2) ;
        Fight (P2, P1, &al2, &sl1) ;

        if (!sl1 || !sl2) stop_battle = TRUE ; 
        if (!al1 && !al2) stop_battle = TRUE ;
      }
      if (sl1 && sl2) draw = Is_A_Draw (P1,P2) ;
    }
    if      (sl1 && sl2) return 0 ;
    else if (sl1)        return 1 ;
    else                 return 2 ;
  }
  else
  {
    printf ("One of the players has no armed ships!\n") ;
    if (!P1->number_of_armed_ships && !P2->number_of_armed_ships)
       return 0 ;
    else if (!P1->number_of_armed_ships) return 2 ;
    else return 1 ;
  }
}



void Init_Survival_Count (struct group *cur_group)
{
  for (;
       cur_group ;
       cur_group = cur_group->next)
  {
    cur_group->number_survived     = 0 ;
    cur_group->max_number_survived = 0 ;
    cur_group->min_number_survived = cur_group->number ;
  }
}



void Print_Survival_Count (struct group *cur_group)
{
  float tot_mass ;
  float tot_sur_mass ;

  printf ("\n   # D    W    S    C                    T     Survival Rate  Min   Max\n") ;
  for (tot_mass = 0.0, tot_sur_mass = 0.0 ;
       cur_group ;
       cur_group = cur_group->next)
  {
    struct ship_type *cur_type ;
    printf ("% 4d% 5.2f% 5.2f% 5.2f% 5.2f ",
            cur_group->number, cur_group->drive_tech, cur_group->weapons_tech,
            cur_group->shield_tech, cur_group->cargo_tech) ;

    tot_mass += cur_group->number * cur_group->total_mass ;
    cur_type = cur_group->type ;
    if (cur_type) printf ("% 20s", cur_type->name) ;
    printf ("   %f", (float)cur_group->number_survived/
                     ((float)(cur_group->number)*(float)(max_battle))) ;
    tot_sur_mass += cur_group->number * cur_group->total_mass *
                    (float)cur_group->number_survived /
                    ((float)(cur_group->number)*(float)(max_battle)) ;
    printf ("     % 4d  % 4d\n", cur_group->min_number_survived,
                                cur_group->max_number_survived) ;
  }
  printf ("Total fleet mass     %6.0f\n", tot_mass) ;
  printf ("Total surviving mass %6.0f\n", tot_sur_mass) ;
  printf ("Total loss           %6.0f\n", tot_mass - tot_sur_mass) ;
  printf ("\n") ;
}



void Count_Survivors (struct player *P)
{
  int ship ;
  struct group *cur_group ;

  if (debug) printf ("Counting survivors...\n") ;

  for (cur_group = P->groups;
       cur_group ;
       cur_group = cur_group->next) cur_group->temporary = 0 ;

  for (ship = 1;
       ship < P->cur_bat_array_size ;
       ship++)
  {
    if (P->bat_array[ship]) 
    { 
      (P->group_array[P->bat_array[ship]])->temporary++ ;
      if (debug) printf ("S: %s\n",(P->group_array[P->bat_array[ship]])->type->name) ;
    }
  }

  for (cur_group = P->groups;
       cur_group ;
       cur_group = cur_group->next)
  {
    cur_group->number_survived += cur_group->temporary ;
    if (cur_group->temporary > cur_group->max_number_survived)
      cur_group->max_number_survived = cur_group->temporary ;
    if (cur_group->temporary < cur_group->min_number_survived)
      cur_group->min_number_survived = cur_group->temporary ;
  }
}


/****** WOPR.c/Is_A_Draw [1.0a] *
*
*  NAME
*    Is_A_Draw -- Test if situation is a draw.
*  SYNOPSIS
*    result = int Is_A_Draw (struct player *P1, struct player *P2) 
*  FUNCTION
*    Test if either of the players can't destroy the other:
*  INPUTS
*    P1  -- player structure of player 1
*    P2  -- player structure of player 2
*  RESULT
*    TRUE or FALSE.
*  BUGS
*
*  SEE ALSO
*
**********
*/

int Is_A_Draw (struct player *P1, struct player *P2)
{
  int draw ;
  struct group *G1mw, *G2mw, *G1ms, *G2ms ;
 
  if (debug) printf ("Checking for Draw...\n") ;

  G1mw = Max_Weapons (P1) ;
  G2mw = Max_Weapons (P2) ;
  G1ms = Min_Shield (P1) ;
  G2ms = Min_Shield (P2) ;

  if (debug)
  {
    printf ("G1mw %s\n", G1mw->type->name) ;
    printf ("G1ms %s\n", G1ms->type->name) ;
    printf ("G2mw %s\n", G2mw->type->name) ;
    printf ("G2ms %s\n", G2ms->type->name) ;
    printf ("G1mw > G2ms %d\n", Can_Destroy(G1mw, G2ms)) ;   
    printf ("G2mw > G1ms %d\n", Can_Destroy(G2mw, G1ms)) ;   
  }
  draw = FALSE ;
  if (G1mw != NULL && G1ms != NULL && G2mw != NULL && G2ms != NULL)
  {
    if (!Can_Destroy (G1mw, G2ms) &&
        !Can_Destroy (G1mw, G2mw) &&
        !Can_Destroy (G2mw, G1mw)) draw = TRUE ;
    if (!Can_Destroy (G2mw, G1ms) &&
        !Can_Destroy (G2mw, G1mw) &&
        !Can_Destroy (G1mw, G2mw)) draw = TRUE ;
  }
  return draw ;
}


/****** WOPR.c/Can_Destroy [1.0a] *
*
*  NAME
*    Can_Destroy -- Test whether one ship can destroy another.
*  SYNOPSIS
*    int Can_Destroy (struct group *g1, struct group *g2) 
*  FUNCTION
*    Test whether one type of ship can destroy another type of ship.
*    this that: is P(kill) > 0
*  INPUTS
*    g1  -- the group the attacking ship belongs to.
*    g2  -- the group the defending ship belongs to.
*  RESULT
*    TRUE or FALSE.
*  BUGS
*
*  SEE ALSO
*
**********
*/

int Can_Destroy (struct group *g1, struct group *g2)
{
  int  can_destroy ;

  if      ((g2->eff_shield eq 0)  &&  (g1->eff_weapons > 0))
    can_destroy = TRUE ;
  else if ((g2->eff_shield eq 0)  &&  (g1->eff_weapons eq 0))
    can_destroy = FALSE ;
  else if (((my_log2(g1->eff_weapons/(g2->eff_shield*3.1072325))/1.386294+1)/2) > 0)
    can_destroy = TRUE ;
  else 
    can_destroy = FALSE ;
  return can_destroy ;
}


struct group *Max_Weapons (struct player *P)
{
  int cur_ship ;
  struct group *max_group ;
  float max_weapons ;

  for (cur_ship = 1, max_weapons = 0, max_group = NULL ;
       cur_ship < P->cur_bat_array_size ;
       cur_ship++)
  {
    struct group *cur_group ;
    int    index ;
    if (index = P->bat_array[cur_ship])
    {
      cur_group = P->group_array[index] ;
      if (cur_group->eff_weapons >= max_weapons) 
      {
        max_weapons = cur_group->eff_weapons ;     
        max_group  = cur_group ;
      }
    }
  }
  return max_group ;
}


struct group *Min_Shield (struct player *P)
{
  int cur_ship ;
  struct group *min_group ;
  float min_shield ;

  for (cur_ship = 1, min_shield = 999999.99, min_group = NULL ;
       cur_ship < P->cur_bat_array_size ;
       cur_ship++)
  {
    struct group *cur_group ;
    int    index ;
    if (index = P->bat_array[cur_ship])
    {
      cur_group = P->group_array[index] ;
      if (cur_group->eff_shield <= min_shield) 
      {
        min_shield = cur_group->eff_shield ;     
        min_group  = cur_group ;
      }
    }      
  }
  return min_group ;
}


/****** WOPR.c/Fight [1.0a] *
*
*  NAME
*    Fight -- fight a battle between ships
*  SYNOPSIS
*    Fight (struct player *P1, struct player *P2, int *al, int *sl)
*  FUNCTION
*    Select a armed ship of player one.
*    for each of its attack select a ship of player two and fire on it.
*  INPUTS
*    P1  -- player structure of player 1
*    P2  -- player structure of player 2
*  RESULT
*    al -- flag: attacking ships left
*    sl -- flag: ships left
*  BUGS
*
*  SEE ALSO
*
**********
*/

void Fight (struct player *P1, struct player *P2, int *al, int *sl)
{
  int att_ship, def_ship ;

  if (*al = att_ship = Select_Armed_Ship (P1))
  {
    int attack ;
    struct group *att_group ;

    att_group = P1->group_array[P1->bat_array[att_ship]] ;
    for (attack = (int)(att_group->type)->attacks, *sl = TRUE ;
         attack > 0 && *sl ;
         attack--)
    {
      if (*sl = def_ship = Select_a_Ship (P2))
      {
        struct group *def_group ;
        float P_Kill ;

        def_group = P2->group_array[P2->bat_array[def_ship]] ;
        if (verb) printf ("% 20s [% 3d] attacks %-20s", (att_group->type)->name, attack,
                                                 (def_group->type)->name) ;
        if (att_group->eff_weapons eq 0.0) printf ("ERROR!!!\n") ;
        if (def_group->eff_shield > 0.0)
        {
          P_Kill = (my_log(att_group->eff_weapons/(def_group->eff_shield*3.1072325))/1.386294+1)/2.0 ;
          if      (P_Kill >= 1.0)
          {
            P2->bat_array[def_ship] = 0 ;
            if (verb) printf (" -- Destroyed\n") ;
          }
          else if (P_Kill > 0)
          {
            if (Roll_Dice () < P_Kill)
          {
            P2->bat_array[def_ship] = 0 ;
            if (verb) printf (" -- Destroyed\n") ;
          }
            else if (verb) printf (" -- Survived\n") ;
          }
          else
          {
            if (verb) printf (" -- Survived\n") ;
          }
        }
        else
        {
          P2->bat_array[def_ship] = 0 ;
          if (verb) printf (" -- Destroyed\n") ;
        }
      }
    }
  }
}



/****** WOPR.c/Select_Armed_Ship [1.0a] *
*
*  NAME
*    Select_Armed_Ship -- select an armed ship.
*  SYNOPSIS
*    ship = int Select_Armed_Ship (struct player *P)
*  FUNCTION
*    Select the next ship that hasn't fired yet, skip the ships
*    that have been destroyed.
*  INPUTS
*    P  -- player structure of a player
*  RESULT
*    ship -- selected ship,  0 if there are none left.
*  BUGS
*
*  SEE ALSO
*
**********
*/

int Select_Armed_Ship (struct player *P)
{
  int ship ;

  for (ship = P->selected_armed_ship ;
       ship <= P->number_of_armed_ships && !P->bat_array[ship] ;
       ship++) ;
  if (ship <= P->number_of_armed_ships)
  {
    P->selected_armed_ship = ship+1 ;
    return ship ;
  }
  else return 0 ;
}


/****** WOPR.c/Load_Fleet_Information [1.3] *
*
*  NAME
*    Load_Player_Data -- load groups and ship types.
*  SYNOPSIS
*    int Load_Player_Data (struct player *P, char *fleet_file_name)
*  FUNCTION
*    Load groups and ship type data, store that in two list structure.
*    Allocate a group array and a battle array.
*    Store all this information in the player structure.
*  INPUTS
*    P               -- player structure.
*    fleet_file_name -- name of the file that groups and ship types
*  RESULT
*    TRUE  -- data loaded.
*    FALSE -- there was an error.
*  BUGS
*  SEE ALSO
*
**********
*/


int Load_Fleet_Information (struct player *P, char *fleet_file_name)
{
  int all_ok = TRUE ;
  FILE *fleet_file ;
  struct group *armed_groups   = NULL ;
  struct group *unarmed_groups = NULL ;
  struct group *cur_group ;

  printf ("\n==== Loading Player Data ====\n") ;
  printf ("-- File: %s\n", fleet_file_name) ;

  P->types = NULL ;
  if (fleet_file = fopen (fleet_file_name, "r"))
  {
    fgets (line_buffer, LINE_BUFFER_LENGTH-2, fleet_file) ;
    for (;
         !feof(fleet_file) && all_ok ;
        )
    {
      int count ;

      struct ship_type *first_type = NULL ;
      struct ship_type *new_type ;
      struct ship_type *cur_ship ;

      /* Read Ship Types */
      printf ("-- Reading ship types\n") ;
      for (;!feof (fleet_file) && *line_buffer != '@' && all_ok ;)
      {
        new_type = (struct ship_type *)malloc (sizeof (struct ship_type)) ;
        count = sscanf (line_buffer, "%s%f%f%f%f%f",
                        new_type->name, &(new_type->drive), &(new_type->attacks),
                        &(new_type->weapons), &(new_type->shield),
                        &(new_type->cargo)) ;
        if (count > 0)
        {
          if (count == 6)
          {
            new_type->next = first_type ;
            first_type = new_type ;
          }
          else
          {
            printf ("ERROR: Malformed ship type.\n --> \"%s\"", line_buffer) ;
            all_ok = FALSE ;
          }
        }
        fgets (line_buffer, LINE_BUFFER_LENGTH-2, fleet_file) ;
      }

      /* Read Groups */
      printf ("-- Reading groups\n") ;
      fgets (line_buffer, LINE_BUFFER_LENGTH-2, fleet_file) ;
      for (;!feof (fleet_file) && *line_buffer != '@' && all_ok ;)
      {
        struct group *new_group ;
        struct ship_type *cur_type ;
        char type_name[NAME_LENGTH] ;
        int count ;

        new_group = (struct group *)malloc (sizeof (struct group)) ;
        count = sscanf (line_buffer, "%d%s%f%f%f%f",
                        &(new_group->number), type_name,
                        &(new_group->drive_tech), &(new_group->weapons_tech),
                        &(new_group->shield_tech), &(new_group->cargo_tech)) ;
        if (count eq 6)
        {
          for (cur_type = first_type ;
               cur_type && strcmp(cur_type->name, type_name) ;
               cur_type = cur_type->next) ;
          new_group->type = cur_type ;
          if (!cur_type)
          {
            printf ("ERROR: Can't find ships type %s.\n", type_name) ;
            all_ok = FALSE ;
          }
          else
          {
            if (new_group->weapons_tech)
            {
              new_group->next = armed_groups ;
              armed_groups = new_group ;
            }
            else
            {
              new_group->next = unarmed_groups ;
              unarmed_groups  = new_group ;
            }
          }
        }
        else
        {
          if (count > 0)
          {
            printf ("ERROR: Error in group entry.\n  -->\"%s\"", line_buffer) ;
            all_ok = FALSE ;
          }
        }
        fgets (line_buffer, LINE_BUFFER_LENGTH-2, fleet_file) ;
      }
      if (P->types)
      {
        for (cur_ship = P->types ;
             cur_ship->next ;
             cur_ship = cur_ship->next) ;
        cur_ship->next = first_type ;
      }
      else P->types = first_type ;


      fgets (line_buffer, LINE_BUFFER_LENGTH-2, fleet_file) ;
    }
    fclose (fleet_file) ;
  }
  else
  {
    printf ("ERROR: can't open file %s.\n", fleet_file_name) ;
    all_ok = FALSE ;
  }

  if (armed_groups) 
  {
    for (cur_group = armed_groups ;
         cur_group->next  ;
         cur_group = cur_group->next) ;
    cur_group->next = unarmed_groups ;
    P->groups = armed_groups ;
  }
  else P->groups = unarmed_groups ;

  if (all_ok)
  {
    Print_Ship_Types (P->types) ;
    Compute_Eff_Shield_And_Weapon (P->groups) ;
    Print_Groups (P->groups) ;
    P->bat_array   = Alloc_Bat_array   (P->groups, &P->bat_array_size) ;
    P->group_array = Alloc_Group_array (P->groups, &P->group_array_size) ;
  }

  return (all_ok) ;
}




/*==================*/


void Compute_Eff_Shield_And_Weapon (struct group *the_groups)
{
  struct group *cur_group ;

  printf ("-- Computing effective shield and weapons.\n") ;
  for (cur_group = the_groups ;
       cur_group ;
       cur_group = cur_group->next)
  {
    float total_mass ;

    total_mass  = (cur_group->type)->drive  ;
    total_mass += (cur_group->type)->shield ;
    total_mass += (cur_group->type)->cargo  ;
    if ((cur_group->type)->attacks)
    {
      if ((cur_group->type)->attacks eq 1)
      {
        total_mass += ((cur_group)->type)->weapons ;
      }
      else
      {
        total_mass += ((cur_group)->type)->weapons +
                      ((cur_group->type)->attacks-1)*
                      (cur_group->type)->weapons/2 ;
      }
    }
    cur_group->total_mass  = total_mass ;
    cur_group->eff_shield  = cur_group->shield_tech*
                             (cur_group->type)->shield /
                             pow(total_mass, 0.33333) ;
    cur_group->eff_weapons = cur_group->weapons_tech*
                             (cur_group->type)->weapons ;
    cur_group->eff_range   = 20*cur_group->drive_tech*
                             (cur_group->type)->drive /
                             total_mass ;
  }
}


/****** WOPR.c/Select_a_Ship [1.0a] *
*
*  NAME
*    Select_a_Ship -- randomly select a ship.
*  SYNOPSIS
*    int Select_a_Ship (struct player *P)
*  FUNCTION
*    Randomly selects a non zero entry in the battle array.
*  INPUTS
*    P -- player structure
*  RESULT
*    0 -- no ships left, otherwise index number of the ship.
*  BUGS
*  SEE ALSO
*
**********
*/


int Select_a_Ship (struct player *P)
{
  int ship ;

  if (P->cur_bat_array_size eq 0)
  {
    printf ("ERROR: internal error -- bat_array_size == 0\n") ; exit (1000) ;
  }

  if (P->cur_bat_array_size eq 1)  ship = 0 ;
  else
  {
    int rep ;

    for (rep = 0, ship = 0 ;
         rep < MAX_REPEAT && !P->bat_array[ship] ;
         rep++)  ship = Random () % (P->cur_bat_array_size - 1) + 1 ;

    if (!P->bat_array[ship])
    {
      int old_ship, new_ship, cur_ship ;
      int new_number_of_armed_ships ;
      int new_selected_armed_ship ;

      if (debug)
      {
        int i ;
        printf ("Could not locate a ship, compacting battle array\n") ;
        printf ("Cur battle array size %d\n", P->cur_bat_array_size) ;
        for (i=0;i<P->cur_bat_array_size;i++) printf ("[%d]",P->bat_array[i]) ;
        printf ("\n") ;
      }

      for (cur_ship = 1, new_number_of_armed_ships = 0;
           cur_ship <= P->number_of_armed_ships;
           cur_ship++)
      {
        if (P->bat_array[cur_ship]) new_number_of_armed_ships++ ;
      }

      for (old_ship = 1, new_ship = 0,
           new_selected_armed_ship = P->selected_armed_ship ;
           old_ship < P->cur_bat_array_size ;
           old_ship++)
      {
        if (P->bat_array[old_ship])
        {
          new_ship++ ;
          P->bat_array[new_ship] = P->bat_array[old_ship] ;
        }
        else
        {
          if (old_ship < P->selected_armed_ship) new_selected_armed_ship-- ;
        }
      }

      P->cur_bat_array_size    = new_ship+1 ;
      P->number_of_armed_ships = new_number_of_armed_ships ;
      P->selected_armed_ship   = new_selected_armed_ship ;

      if (debug)
      {
        printf ("New Battle Array Size %d.\n", P->cur_bat_array_size) ;
      }

      if (P->cur_bat_array_size != 1)
      {
        ship = Random () % (P->cur_bat_array_size - 1) + 1 ;
        if (!P->bat_array[ship])
        {
          int i ;
          printf ("ERROR: Internal error -- can't find ship after comp.\n") ;
          printf (" ship = %d\n", ship) ;
          for (i=0 ; i<new_ship; i++) printf ("%d\n",P->bat_array[i]) ;
          exit(0) ;
          ship = 0 ;
        }
      }
      else ship = 0 ;
    }
  }
  return ship ;
}




void Randomize_Armed_Ships (short *bat_array, int number_of_armed_ships)
{
  int i, ship1, ship2 ;

  if (debug)
  {
     printf ("-- Randomizing Armed Ships.\n") ;
     printf ("   Number of Armed Ships %d\n", number_of_armed_ships) ;
  }
  for (i = 0; i < number_of_armed_ships ; i++)
  {
    short temp ;
    ship1 = Random () % number_of_armed_ships + 1 ;
    ship2 = Random () % number_of_armed_ships + 1 ;
    temp = bat_array[ship1] ;
    bat_array[ship1] = bat_array[ship2] ;
    bat_array[ship2] = temp ;
  }
  if (debug) printf ("   Ready...\n") ;
}



int Init_Bat_array (short *bat_array, struct group *the_groups)
{
  struct group *cur_group ;
  short cur_group_id ;
  int number_of_armed_ships ;

  if (debug) printf ("-- Initializing Batlle Array.\n") ;
  bat_array++ ;
  for (cur_group = the_groups, cur_group_id = 1, number_of_armed_ships = 0 ;
       cur_group ;
       cur_group = cur_group->next, cur_group_id++)
  {
    int number_of_ships, cur_ship ;

    number_of_ships = cur_group->number ;
    if (cur_group->weapons_tech > 0)  number_of_armed_ships += number_of_ships ;

    for (cur_ship = 0 ;
         cur_ship < number_of_ships ;
         cur_ship++)
    {
      *bat_array = cur_group_id ;
      bat_array++ ;
    }
  }
  return number_of_armed_ships ;
}



short *Alloc_Bat_array (struct group *the_groups, int *size)
{
  struct group *cur_group ;
  short *bat_array ;
  int number_of_ships ;

  for (cur_group = the_groups, number_of_ships = 0 ;
       cur_group ;
       cur_group = cur_group->next) number_of_ships += cur_group->number ;
  printf ("-- Allocating Battle Array...\n") ;
  printf ("-- Total number of ships %d.\n", number_of_ships) ;
  *size = number_of_ships+1 ;
  bat_array = (short *)calloc (*size, sizeof(short)) ;
  return bat_array ;
}



struct group **Alloc_Group_array (struct group *the_groups, int *size)
{
  struct group *cur_group ;
  struct group **group_array ;
  int number_of_groups ;

  printf ("-- Allocating Group Array...\n") ;
  for (cur_group = the_groups, number_of_groups = 0 ;
       cur_group ;
       cur_group = cur_group->next) number_of_groups++ ;
  printf ("-- Total number of groups %d.\n", number_of_groups) ;
  *size = number_of_groups+1 ;
  group_array = (struct group **)calloc (*size, sizeof(struct group *)) ;
  if (group_array)
  {
    struct group **cur_elem ;
    *group_array = NULL ;
    for (cur_group = the_groups, cur_elem = group_array+1 ;
         cur_group ;
         cur_group = cur_group->next)
    {
      *cur_elem = cur_group ;
      cur_elem++ ;
    }
  }
  return group_array ;
}


void Print_Ship_Types (struct ship_type *cur_type)
{
  printf ("\n                 T      D       A       W       S       C\n") ;
  for (;
       cur_type ;
       cur_type = cur_type->next)
  { printf ("%20s % 7.2f % 7.2f % 7.2f % 7.2f % 7.2f\n",
            cur_type->name, cur_type->drive, cur_type->attacks,
            cur_type->weapons, cur_type->shield, cur_type->cargo) ;
  }
  printf ("\n") ;
}


void Print_Groups (struct group *cur_group)
{
  printf ("\n   # D    W    S    C                     T      Seff    Weff    Reff\n") ;
  for (;
       cur_group ;
       cur_group = cur_group->next)
  {
    struct ship_type *cur_type ;
    printf ("% 4d% 5.2f% 5.2f% 5.2f% 5.2f ",
            cur_group->number, cur_group->drive_tech, cur_group->weapons_tech,
            cur_group->shield_tech, cur_group->cargo_tech) ;
    cur_type = cur_group->type ;
    if (cur_type)  printf ("% 20s", cur_type->name) ;
    printf (" %7.2f", cur_group->eff_shield) ;
    printf (" %7.2f", cur_group->eff_weapons) ;
    printf (" %7.2f\n", cur_group->eff_range) ;
  }
  printf ("\n") ;
}




/*-------------------------------------------*/
/* Random Number Generator Package           */
/* Additive method as outlined in            */
/* Knuth's "The art of computer programming" */
/*-------------------------------------------*/

/* Some Vars for the Random Number Generator */
unsigned long Ran_tab[55] ;
int Ran_k = 23 ;
int Ran_j = 54 ;

float Roll_Dice ()
{
  return ((float)((Random () & 65535)/65535.0)) ;
}

unsigned long Random ()
{
  Ran_tab[Ran_k] += Ran_tab[Ran_j] ;
  Ran_k-- ;  Ran_j-- ;
  if (Ran_k < 0) Ran_k = 54 ;
  if (Ran_j < 0) Ran_j = 54 ;
  return (Ran_tab[Ran_k]) ;
}

void Reset_Random (unsigned long Seed)
{
  unsigned long rval ;
  int i ;
  rval = Seed ;
  for (i = 0; i < 55; i++)
  {
    rval = ((((rval >> 31)^(rval >> 6)^(rval >> 4)^(rval >> 2)
      ^(rval >>1)^rval)&0x1)<<31) | (rval>>1) ;
    Ran_tab[i] = rval ;
  }
  Ran_k = 23 ;
  Ran_j = 54 ;
  for (i = 0; i < 4000; i++) Random () ;
}


float my_log (float x) 
{
  if (x <= 0) { printf ("ERROR: --- %f\n", x) ; exit (100) ; }
  return (log(x)) ;
}


float my_log2 (float x) 
{
  if (x <= 0) return (-1.0) ; 
  return (log(x)) ;
}


