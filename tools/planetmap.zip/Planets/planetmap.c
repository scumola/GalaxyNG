/*
  $Id: planetmap.c,v 1.1 1999/11/28 10:31:07 galaxy-dev Exp $
 */

/****h* GalaxyTools/planetmap.c [1.0d] *
*   NAME
*     planetmap.c -- create a gnuplot program to plot a map of the galaxy.
*
*  COPYRIGHT
*    (c) Maverick Software Development 1996.
*    This software is public domain and can be freely redistributed as
*    long as it remains in its original state.
*
*  SYNOPSIS
*    planetmap <turn-report> [-p] [-mag <bl_x> <bl_y> <width> <height>]
*
*  INPUTS
*    turn_report  -- a turn report file.
*    -p           -- flag to indicate you want gnuplot to create
*                    a postscript file instead of a plot on the
*                    screen.
*    -mag         -- flag to indicated you want to zoom in to an area.
*    bl_x         -- bottom left corner  x-coordinate.
*    bl_y         -- bottem left corner  y-coordinate.
*    width        -- width of the enlarged section.
*    height       -- height of the enlarged section.
*
*  FUNCTION
*    This is a galaxy tool that given a turn report creates
*    a gnuplot program that makes a map of your current situation
*    in the galaxy.
*
*    The map includes:
*    o Your Planets
*    o Your Enemies Planets
*    o All  Uninhabited planets.
*
*    planetmap creates 4 files:
*    1 planets.mine    a list of all your planets,
*    2 planets.full    a list of all planets of your enemies,
*    3 planets.empty   a list of all Uninhabited planets,
*    4 galaxy_map.gnu  the gnuplot file.
*
*    
*    To view the map type:
*
*      gnuplot galaxy_map.gnu 
*
*    If you used the -p option to create a Postscript file
*    type:
*
*      gnuplot galaxy_map.gnu >map.ps
*
*    You can then view the map with ghostview, or print it.
*
*    If you like a smaller font change the line 
*       set term postscript
*    to
*       set term postscript "times" 5
*
*    In addition you can use the program dist to compute the
*    various distances between planets, you can create an input
*    file for this program from the output files of planets,
*    using:
*
*       cat pl* >all_planets          (UNIX)
*       join pl#? to all_planets      (Amiga)
*
*  RESULT
*    A gnuplot program.
*
*  AUTHOR
*    Frans Slothouber
*
*  CREATION DATE
*    Sep-1996, based on makemap.c
*
*  MODIFICATION HISTORY
*    08-Sep-1996   V1.0
*    24-Sep-1996   V1.0a   - Better documentation.
*    30-Sep-1996   V1.0b   - bug fix
*    30-Sep-1996   V1.0c   - bug fix
*    20-Feb-1997   V1.0d   - bug fix by Arjan Kenter.
*    03-OCT-1999   V1.0e   - name change, called planetmap instead
*                            of planets.
*  NOTES
*    Has been successfully compiled with:
*      o SAS 6.50 and DICE on an Amiga.
*      o with gcc on a Sun Sparc Station running Solaris.
*        using   gcc planetmap.c -o planetmap -lm
*
*  BUGS
*    o Sometimes a mail program will split lines that are longer than
*      80 chars. This causes the information about your planets in the turn
*      report to be split in two lines. You have to fix this first before
*      you can use planetmap.
*
*    o This program fails when you don't own any planets.
*
*    Found other bugs?
*    Catch them in a jar and send them to fslothouber@acm.org
*
**********
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define TRUE        1
#define FALSE       0
#define eq          ==
#define BIG_ERROR   100
#define BUFFER_SIZE 255
#define NAME_LENGTH 32

enum { PL_YOURS = 1, PL_FULL, PL_EMPTY } ;
enum { POSTSCRIPT = 1, GRAPHICS } ;

typedef struct planet
{
  struct planet *next ;
  int type ;
  char name[NAME_LENGTH] ;
  float x,y ;
  float size, resources ;
  float population, industry ;
} a_planet ;

typedef struct map
{
  float size ;
  int output ;
  float bl_x, bl_y, width, height ;
  a_planet *planet_list ;
} a_map ;


void Usage             (void) ;
int  Get_Map_Size      (FILE *rfile, char *buffer, a_map *map) ;
void Get_Planets       (FILE *rfile, char *buffer, a_map *map) ;
int  Find_Marker       (FILE *rfile, char *buffer, char *marker) ;
void Get_Planet_Data   (FILE *rfile, char *buffer, a_map *map, int type_planet) ;
void Create_Plot_Files (a_map *map) ;
void Create_Data_File  (char *file_name, a_map *map, int planet_type) ;
int find_flag          (int arg_count, char **av, char *flag) ;
int Analyse_Mag        (int arg_count, char **av, a_map *map) ;
void Create_GNU_File   (a_map *map) ;



int main (int arg_count, char **av)
{
  int return_code = 0 ;

  if (arg_count <= 1)
  {
    Usage () ; return_code = BIG_ERROR ;
  }
  else
  {
    char line_buffer[BUFFER_SIZE] ;
    a_map galaxy_map ;
    FILE *report_file ;

    galaxy_map.planet_list = NULL ;

    if (find_flag (arg_count, av, "-p")) { galaxy_map.output = POSTSCRIPT ; }
    else                                 { galaxy_map.output = GRAPHICS ; }

    if (report_file = fopen (av[1], "r"))
    {
      Get_Map_Size (report_file, line_buffer, &galaxy_map) ;
      if (find_flag (arg_count, av, "-mag"))
      {
        Analyse_Mag (arg_count, av, &galaxy_map) ;
      }
      Get_Planets  (report_file, line_buffer, &galaxy_map) ;
      fclose (report_file) ;
      Create_Plot_Files (&galaxy_map) ;
    }
    else
    {
      printf ("Error: can't open report file %s\n", av[1]) ;
      Usage () ;
    }
  }
  return return_code ;
}


int find_flag (int arg_count, char **av, char *flag)
{
  int result ;
  int index ;

  for (result = FALSE, index = 2 ;
       index < arg_count && !result ;
       index++) if (strstr (av[index], flag)) { result = TRUE ; }
  return result ;
}

int Analyse_Mag (int arg_count, char **av, a_map *map)
{
  int result ;
  int index ;

  for (result = FALSE, index = 2 ;
       index < arg_count && !result ;
       index++) if (strstr (av[index], "-mag")) { result = TRUE ;  }

  if ((arg_count - index) < 4)
  {
    printf ("Error in -mag option\n") ;
    Usage () ;
    result = FALSE ;
  }
  else
  {
    map->bl_x = atof (av[index+0]) ;    map->bl_y = atof (av[index+1]) ;
    map->width = atof (av[index+2]) ;   map->height = atof (av[index+3]) ;
  }
  return result ;
}


void Usage (void)
{
  printf (
  "Usage:\n"
  "planetmap <report file>\n"
         ) ;
  exit (100) ;
}

void Create_Plot_Files (a_map *map)
{
  Create_Data_File ("planets.mine", map,  PL_YOURS) ;
  Create_Data_File ("planets.full", map,  PL_FULL) ;
  Create_Data_File ("planets.empty", map, PL_EMPTY) ;
  Create_GNU_File (map) ;
}

void Create_Data_File (char *file_name, a_map *map, int planet_type)
{
  FILE *data_file ;

  if (data_file = fopen (file_name, "w"))
  {
    a_planet *cur_planet ;

    for (cur_planet = map->planet_list ;
         cur_planet ;
         cur_planet = cur_planet->next)
    {
      if (cur_planet->type eq planet_type)
      {
        if (cur_planet->x >= map->bl_x &&
            cur_planet->x <= (map->bl_x + map->width) &&
            cur_planet->y >= map->bl_y &&
            cur_planet->y <= (map->bl_y + map->height))
        {
          fprintf (data_file, "%s %7.2f %7.2f  %7.2f %7.2f %7.2f %7.2f\n",
                   cur_planet->name, cur_planet->x, cur_planet->y,
                   cur_planet->size, cur_planet->resources,
                   cur_planet->population, cur_planet->industry) ;
        }
      }
    }
    fclose (data_file) ;
  }
  else { printf ("Error: can't open %s\n", file_name) ; }
}


void Create_GNU_File (a_map *map)
{
  FILE *gnu_file ;

  if (gnu_file = fopen ("galaxy_map.gnu", "w"))
  {
    a_planet *cur_planet ;
    if (map->output eq POSTSCRIPT)
    { fprintf (gnu_file, "set term postscript \"times\" 8\n") ; }
    fprintf (gnu_file,
             "set nokey\n",
             "set parametric\n") ;
    fprintf (gnu_file, "set xrange [%.2f:%.2f]\n",
             map->bl_x, map->bl_x+map->width) ;
    fprintf (gnu_file, "set yrange [%.2f:%.2f]\n",
             map->bl_y+map->height, map->bl_y) ;
    for (cur_planet = map->planet_list ;
         cur_planet ;
         cur_planet = cur_planet->next)
    {
       if (cur_planet->x >= map->bl_x &&
           cur_planet->x <= (map->bl_x + map->width) &&
           cur_planet->y >= map->bl_y &&
           cur_planet->y <= (map->bl_y + map->height))
       {
         fprintf (gnu_file, "set label \" %s\" at %.2f, %.2f\n",
                 cur_planet->name, cur_planet->x, cur_planet->y) ;
       }
    }
    fprintf (gnu_file, "plot \"planets.empty\" using 2:3,\\\n"
             " \"planets.full\" using 2:3,\\\n"
             " \"planets.mine\" using 2:3\n") ;
    if (map->output != POSTSCRIPT)
    { fprintf (gnu_file, "pause -1\n") ; }
  }
  else { printf ("Error: can't open galaxy_file\n") ; }
}



#define find(marker) Find_Marker (rfile, buffer, marker)

void Get_Planets (FILE *rfile, char *buffer, a_map *map)
{
  if (find("Your Planets"))
  {
    Get_Planet_Data (rfile, buffer, map, PL_YOURS) ;
  }
  else { rewind (rfile) ; }

  if (find("Planets"))
  {
    if (!strstr (buffer, "Uninhabited"))
    {
      Get_Planet_Data (rfile, buffer, map, PL_FULL) ;
      for (find("Planets") ;
           !strstr (buffer, "Uninhabited") && !feof (rfile) ;
           find("Planets"))
      {
        Get_Planet_Data (rfile, buffer, map, PL_FULL) ;
      }
      if (!feof (rfile))
      {
        Get_Planet_Data (rfile, buffer, map, PL_EMPTY) ;
      }
    }
    else
    {
      Get_Planet_Data (rfile, buffer, map, PL_EMPTY) ;
    }
  }
}



#define get_line  fgets (buffer, BUFFER_SIZE - 2, rfile)

void Get_Planet_Data (FILE *rfile, char *buffer, a_map *map, int planet_type)
{
  if (!feof (rfile))
  {
    get_line ; get_line ;
    for (; !isspace(*buffer) && !feof (rfile) ; )
    {
      get_line ;
      if (!isspace(*buffer))
      {
        a_planet *cur_planet ;
        if (cur_planet = malloc (sizeof (a_planet)))
        {
          int nr_read ;
          float t1,t2,t3,t4 ;

          cur_planet->next = map->planet_list ;
          map->planet_list = cur_planet ;
          cur_planet->type = planet_type ;
          nr_read = sscanf (buffer, "%s%f%f%f%f%f%f",
                            cur_planet->name, &(cur_planet->x),
                            &(cur_planet->y),
                            &t1, &t2, &t3, &t4) ;
          if (nr_read eq 5)
          {
            cur_planet->size = t1 ;
            cur_planet->resources = t2 ;
            cur_planet->population = cur_planet->industry = 0.0 ;
          }
          else if (nr_read eq 7)
          {
            cur_planet->size = t1 ;
            cur_planet->resources = t2 ;
            cur_planet->population = t3 ;
            cur_planet->industry = t4 ;
          }
          else
          {
            cur_planet->size = cur_planet->resources = 0.0 ;
            cur_planet->population = cur_planet->industry = 0.0 ;
          }
        }
      }
    }
  }
}


int Get_Map_Size (FILE *rfile, char *buffer, a_map *map)
{
  int result ;
/* set default values */
  map->bl_x = 0.0 ;
  map->bl_y = 0.0 ;
  map->width  = 100.0 ;
  map->height = 100.0 ;

  if (result = Find_Marker (rfile, buffer, "Status of Players"))
    if (result = Find_Marker (rfile, buffer, "----------------"))
      if (result = Find_Marker (rfile, buffer, "----------------"))
      {
        float size ;
        get_line ;
        if ((sscanf (buffer, "%*f,%f", &size)) eq 1)
        {
          map->width = map->height = map->size = size ;
        }
        else result = FALSE ;
      }
  return result ;
}


int Find_Marker (FILE *rfile, char *buffer, char *marker)
{
  char *found ;
  for (found = NULL ; !found && !feof (rfile) ; )
  {
    get_line ;
    found = strstr (buffer, marker) ;
  }
  return (found ? TRUE : FALSE) ;
}

